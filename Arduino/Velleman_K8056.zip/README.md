# VellemanK8056library
An Arduino library for controlling a Velleman K8056 relayboard using a serial connection

For documentation please see: https://reptile-addict.nl/wp/velleman/

