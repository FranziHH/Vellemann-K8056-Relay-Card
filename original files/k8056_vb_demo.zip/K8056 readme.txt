K8056  Readme
**************

This software demonstrates a way to control the K8056 relay board via RS232.
It is supplied 'as-is' i.e. no guarantees are made, no responsabilities are takes.
Use at your own risk !

Please check the K8056 manual for communication protocol details.


If you intend to use or analyse the VB source, make sure you set the right path (e.g. ..\velleman\K8056\K8056.frm for the main form and make sure you select 'startup from form1'.






