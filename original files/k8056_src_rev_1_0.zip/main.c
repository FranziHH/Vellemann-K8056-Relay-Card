/*
 * Replacement firmware for K8056 8-Channel Relay Card produced by Velleman� Inc.
 *
 * Copyright (C) 2015 Siarzhuk Zharski <imker@gmx.li>
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 *
 */
#if defined(__XC)
	#include <xc.h>			/* XC8 General Include File */
#elif defined(HI_TECH_C)
	#include <htc.h>		/* HiTech General Include File */
#endif

#include <stdint.h>			/* For uint8_t definition */
#include <stdbool.h>		/* For true/false definition */


// Configuration bits

#pragma config FOSC = INTRCIO	// Oscillator Selection bits (INTOSC oscillator:
								// I/O function on RA4/OSC2/CLKOUT pin, I/O
								// function on RA5/OSC1/CLKIN)

#pragma config WDTE = OFF		// Watchdog Timer Enable bit (WDT disabled)
#pragma config PWRTE = OFF		// Power-up Timer Enable bit (PWRT disabled)

#pragma config MCLRE = OFF		// RA3/MCLR pin function select (RA3/MCLR pin
								// function is digital I/O,
								// MCLR internally tied to VDD)

#pragma config BOREN = OFF		// Brown-out Detect Enable bit (BOD disabled)
#pragma config CP = OFF			// Code Protection bit (Program Memory code
								// protection is disabled)

#pragma config CPD = OFF		// Data Code Protection bit (Data memory code
								// protection is disabled)

#define _XTAL_FREQ		4000000	// 4 MHz


// Global declarations
#define BITNUM(adr, bit)((unsigned)(&adr) * 8 + (bit))

static bit TEST_BUTTON	@ BITNUM(PORTA, 2);
static bit RS232_INPUT	@ BITNUM(PORTA, 3);
static bit NO_REMCTL	@ BITNUM(PORTA, 4);
static bit LED_DATAIN	@ BITNUM(PORTA, 5);


// bitmap of current state of outputs
uint8_t pins = 0;

// card address
#define EE_CARD_ADDRESS (_EEPROMSIZE - 1) // at 0x7E - the last pos of EEPROM
uint8_t cardAddress = 1;

// one program event
struct {
	uint16_t ticks;
	uint8_t outs;
} prog_event = { 0 };

// some kind of illumination is pre-programmed from 0x00 to 0x7D
__EEPROM_DATA(0x02, 0x00, 0x00, 0x02, 0x00, 0x01, 0x02, 0x00);
__EEPROM_DATA(0x02, 0x02, 0x00, 0x04, 0x02, 0x00, 0x08, 0x02);
__EEPROM_DATA(0x00, 0x10, 0x02, 0x00, 0x20, 0x02, 0x00, 0x40);
__EEPROM_DATA(0x02, 0x00, 0x81, 0x02, 0x00, 0x82, 0x02, 0x00);
__EEPROM_DATA(0x84, 0x02, 0x00, 0x88, 0x02, 0x00, 0x90, 0x02);
__EEPROM_DATA(0x00, 0xA0, 0x02, 0x00, 0xC1, 0x02, 0x00, 0xC2);
__EEPROM_DATA(0x02, 0x00, 0xC4, 0x02, 0x00, 0xC8, 0x02, 0x00);
__EEPROM_DATA(0xD0, 0x02, 0x00, 0xE1, 0x02, 0x00, 0xE2, 0x02);
__EEPROM_DATA(0x00, 0xE4, 0x02, 0x00, 0xE8, 0x02, 0x00, 0xF1);
__EEPROM_DATA(0x02, 0x00, 0xF2, 0x02, 0x00, 0xF4, 0x02, 0x00);
__EEPROM_DATA(0xF9, 0x02, 0x00, 0xFA, 0x02, 0x00, 0x7D, 0x02);
__EEPROM_DATA(0x00, 0xBE, 0x02, 0x00, 0x5F, 0x02, 0x00, 0xAF);
__EEPROM_DATA(0x02, 0x00, 0x57, 0x02, 0x00, 0xAB, 0x02, 0x00);
__EEPROM_DATA(0x55, 0x02, 0x00, 0xAA, 0x02, 0x00, 0x54, 0x02);
__EEPROM_DATA(0x00, 0xA8, 0x02, 0x00, 0x50, 0x02, 0x00, 0xA0);
__EEPROM_DATA(0x02, 0x00, 0x40, 0x02, 0x00, 0x80, 0x00, 0x01);

#define EE_PROGRAM_END (_EEPROMSIZE - 2)
#define EE_PROGRAM_LINES_END (EE_PROGRAM_END / sizeof(prog_event))


// system ticks (every 100 ms)
#define SYSTIMER_TICKS (0xFFFF - 49120)
uint16_t system_ticks = 0;

// RS232 RX interface support
#define RX_BUFFER_SIZE		4
uint8_t rx_buffer[RX_BUFFER_SIZE] = { 0 };
struct {
	unsigned int head: 2;
	unsigned int tail: 2;
	unsigned int on: 1;			// in the middle of command receiving
} rx;
uint8_t rx_count = 0;			// command bytes currently received

#define DATA_IN_ACK_TICKS	6	// about 0.6 seconds
uint8_t rx_ack_ticks = 0;
// duplicate commands sys.ticks timeout - required for toggle function
#define TOGGLE_TO	2


// RS232 receive timeouts - half of start bit and data bits period
#define START_BIT_TICKS (0xFF - 100)
#define DATA_BITS_TICKS (0xFF - 190)

// bitmap of pulse counters - every defines sys.ticks timeout
#define PULSE_BITS	2		// bits reserved for every pin timeout
#define PULSE_MASK	0x03	// mask for every pin bits
#define PULSE_TO	0x03	// 3 ticks about ~300 ms
uint16_t pulses_count = 0;


// button-related test and program support
struct {
	// test mode support
	unsigned int test_pin: 4;
#define M_IDLE	0
#define M_TEST	1
#define M_RUN	2
	unsigned int mode: 2;
	// button
	unsigned int was_pressed: 1;
	// do not execute duplicate commands
	unsigned int cmd_par_bm: 1;
} button;

#define TEST_TICKS_COUNT 10
uint8_t pressed_ticks = 0;
uint8_t prog_item = 0;

// time the prev. command was processed
uint16_t prev_cmd_tick = 0;

// TODO - test place holder - remove ASAP
// volatile uint8_t t[3] = { 0 }; // - placeholder - 4 bytes still available!


void UpdateOutputs()
{
	PORTC = 0x0F & pins >> 4 | (0x01 & pins) << 5 | (0x02 & pins) << 3;
	PORTA = PORTA & 0xFC | 0x03 & pins >> 2;
}


void InitializeIO(void)
{
	// RA0 OUT3
	// RA1 OUT4
	// RA2 Test button (INPUT)
	// RA3 RS232 RX (INPUT)
	// RA4 Remote ON/OFF (INPUT)
	// RA5 LED 10
	TRISA = 0b011100;

	// RC0 OUT5
	// RC1 OUT6
	// RC2 OUT7
	// RC3 OUT8
	// RC4 OUT2
	// RC5 OUT1
	TRISC = 0;

	// disable multiplexing
	CMCONbits.CM = 0b111;	// detach CIN+, CIN-, COUT

	// configure weak pull-ups on input pins
	OPTION_REGbits.nRAPU = 0;
	WPUAbits.WPUA2 = 1;
	WPUAbits.WPUA4 = 1;

	// interrupt on RS232 RX input change
	INTCONbits.RAIE = 1;
	IOCAbits.IOCA3 = 1;

	// configure RX bits timer
	OPTION_REGbits.T0CS = 0; // timer mode
	OPTION_REGbits.PSA = 0; // use prescaler
	OPTION_REGbits.PS = 0; // 1:2

	// enable test button interrupt
	OPTION_REGbits.INTEDG = 0; // falling edge
	INTCONbits.INTF = 0;
	INTCONbits.INTE = 1;

	// start system timer
	TMR1 = SYSTIMER_TICKS;
	T1CONbits.T1CKPS = 0b01; // 1:2 prescale
	T1CONbits.TMR1ON = 1;
	T1CONbits.TMR1CS = 0; // in timer mode
	T1CONbits.TMR1ON = 1;
	PIE1bits.TMR1IE = 1;

	// init outputs to default
	UpdateOutputs();

	// LED D10 off
	LED_DATAIN = 0;

	// enable peripheral and global interrupts
	INTCONbits.PEIE = 1;
	INTCONbits.GIE = 1;
}


void main(void)
{
	// command receiving
	enum {
		ADDRESS = 0,
		COMMAND,
		PARAM,
		PROG_LSB,
		PROG_MSB,
		PROG_PINS,
		COUNT
	};
	static uint8_t command[COUNT] = { 0 };

	static uint8_t byte = 0;
	static uint8_t crc = 0;

	// configure and initialize I/O pins
	InitializeIO();

	// card address in the last byte of EEPROM
	cardAddress = EEPROM_READ(EE_CARD_ADDRESS);
	if (cardAddress < 1) {
		cardAddress = 1;
		goto update_card_address;
	}

	while (1) {

		// wait for data in RX buffer
		while (rx.head == rx.tail) {
			// idle processing
			static uint16_t prev_tick = 0;
			if (prev_tick != system_ticks) {
				prev_tick = system_ticks;

				// process test/run button events
				if (button.was_pressed) {
					if (!TEST_BUTTON) {
						// still pressed - collect duration
						pressed_ticks++;
						continue;
					}

					button.was_pressed = 0;
					if (!pressed_ticks)
						continue;

					// long button event - run the program
					if (pressed_ticks > TEST_TICKS_COUNT) {
						pressed_ticks = 0;
start_auto_programm:
						button.mode = M_RUN;
						prog_item = 0;
						// start blinking
						LED_DATAIN = 1;
						rx_ack_ticks = DATA_IN_ACK_TICKS;
reload_start_ee:
						eecpymem((volatile unsigned char *)&prog_event,
							(eeprom unsigned char *)prog_item,
							sizeof(prog_event));
						continue;
					}
					
					pressed_ticks = 0;

					// short button event - switch to test mode
					if (button.mode != M_TEST) {
						button.mode = M_TEST;
						button.test_pin = 0;

					} else if (++button.test_pin > 7)
						button.mode = M_IDLE;

					pins = 1 << button.test_pin;
					goto set_pins;
				}

				// process another event if the program is running
				if (button.mode == M_RUN && !--prog_event.ticks) {
					pins = prog_event.outs;
					prog_item += 3;
					if (prog_item == EE_PROGRAM_END)
						prog_item = 0;

					eecpymem((volatile unsigned char *)&prog_event,
						(eeprom unsigned char *)prog_item,
						sizeof(prog_event));

					switch (prog_event.ticks) {
						case 0xFFFF:
							if (prog_event.outs == 0xFF)
								button.mode == M_IDLE;
							else {
								// restart at EE address
								prog_item = prog_event.outs;
								goto reload_start_ee;
							}
							break;
						case 0:
							prog_event.ticks++; // at least 100 ms
							break;
					}

					goto set_pins;
				}

				// successfull command visual ack timeout
				if (rx_ack_ticks && 0 == --rx_ack_ticks) {
					if (button.mode == M_RUN) {
						LED_DATAIN = !LED_DATAIN;
						rx_ack_ticks = DATA_IN_ACK_TICKS;
					} else
						LED_DATAIN = 0;
				}

				// are any pulses waiting?
				if (!pulses_count)
					continue;

				uint8_t p;
				for (p = 0; p < 8; p++) {
					uint8_t ticks
						= PULSE_MASK & pulses_count >> p * PULSE_BITS;
					if (0 == ticks) // pin is not pulsed - ignore
						continue;
					if (0 == --ticks) // pulse timed out - clear pin
						pins &= ~(1 << p);
					// update counter for pin
					pulses_count &= ~(PULSE_MASK << p * PULSE_BITS);
					pulses_count |= ticks << p * PULSE_BITS;
				}

				// reapply possibly modified outputs state
				goto set_pins;
			}
		}

		// yet another byte was just received
		byte = rx_buffer[rx.tail++];

		if (!rx.on) {
			if (byte == '\r' && NO_REMCTL) {
				// start of command
				rx.on = 1;
				rx_count = 0;
				button.cmd_par_bm = 0;
				crc = byte;
			}
			continue;
		}

		crc += byte;
		if (rx_count < 6) {
			button.cmd_par_bm |= command[rx_count] != byte;
			command[rx_count++] = byte;
			if (rx_count < 4 || command[COMMAND] == 'W')
				continue;
		}

		rx.on = 0;
		if (crc)
			continue;

		// check the card address
		if (cardAddress != command[ADDRESS]) {
			switch (command[COMMAND]) {
				// only those are broadcasting
				case 'F':
				case 'E':
				case 'D':
					break;
				default:
					continue;
			}
		}

		// check if identical command was just executed
		// less than ~200 ms ago
		if (button.cmd_par_bm == 0
				&& system_ticks - prev_cmd_tick < TOGGLE_TO)
			continue;

		// cannot write EEPROM outside of program area
		if (command[COMMAND] == 'W'
				&& command[PARAM] >= EE_PROGRAM_LINES_END)
			continue;

		prev_cmd_tick = system_ticks;

		// any remote command stops test/run modes
		if (button.mode != M_IDLE) {
			button.mode = M_IDLE;
			pins = 0;
		}

		// received valid command - defer ack timeout for "Data In" LED
		LED_DATAIN = 1;
		rx_ack_ticks = DATA_IN_ACK_TICKS;

		switch (command[COMMAND]) {
			case 'F': // force all cards address to 1
				cardAddress = 1;
				goto update_card_address;
			case 'A': // change the card address
				cardAddress = command[PARAM];
update_card_address:
				memcpyee((eeprom unsigned char *)EE_CARD_ADDRESS,
					&cardAddress, 1);
				break;
			case 'W': // write program line to EEPROM
				byte = command[PARAM]; // sizeof(prog_event) == 3
				byte += command[PARAM];
				byte += command[PARAM] - 3;
				memcpyee((eeprom unsigned char *)byte,
					command + PROG_LSB, sizeof(prog_event));
				pins = command[PROG_PINS];
				break;
			case 'R': // start/stop auto-programm
				if (command[PARAM] == 0) { // stop
					if (button.mode == M_RUN)
						button.mode = M_IDLE;
					continue;
				}
				// else start auto-programm
				if (button.mode != M_RUN)
						goto start_auto_programm;
				// fall through
			default: // unknown command
				continue;

			case 'E': // emergency off all outputs
				pins = 0;
				break;
			case 'D': // display this card address
				pins = cardAddress;
				break;
			case 'B': // set all pins in one byte
				pins = command[PARAM];
				break;

			case 'S': // set the output
			case 'P': // pulse the output
			case 'C': // clear the output
			case 'T': { // toogle the output
				byte = command[PARAM] - '1'; // ASCII to number
				if (byte > 8)
					continue;

				uint8_t pin = 1 << byte;
				uint8_t mask = pin;
				if (byte == 8)
					mask = 0xFF;

				switch (command[COMMAND]) {
					default:
						continue;
					case 'P': // pulse
						pulses_count |= PULSE_TO << byte * PULSE_BITS;
						pins |= pin;
						break;
					case 'S': // set
						pins |= mask;
						break;
					case 'C': // clear
						pins &= ~mask;
						break;
					case 'T': // toggle
						if (byte < 8) {
							if (pins & pin)
								pins &= ~pin;
							else
								pins |= pin;
						} else
							pins = ~pins;
						break;
				}
				break;
			}
		}

set_pins:
		UpdateOutputs();
	}
}


void interrupt isr(void)
{
	static int8_t count = 0;
	static uint8_t byte = 0;

	// detect drop of RS232 RX pin
	if (INTCONbits.RAIE && INTCONbits.RAIF) {
		// clear flag
		INTCONbits.RAIF = 0;

		if (RS232_INPUT) {
			// stop RX on change interrupt
			INTCONbits.RAIE = 0;
			// prepare for possible start bit
			count = -1;
			byte = 0;
			// start RS232 bit bang timer
			INTCONbits.T0IF = 0;
			TMR0 = START_BIT_TICKS;
			INTCONbits.T0IE = 1;
		}
	}

	// RS232 bit bang handling
	if (INTCONbits.T0IE & INTCONbits.T0IF) {
		// clear flag
		INTCONbits.T0IF = 0;

		// reser timer for the next full bit
		TMR0 = DATA_BITS_TICKS;
		// process bytes
		if (count < 0) {
			// start bit not found
			if (!RS232_INPUT)
				goto cleanup;

			// toggle LD10 - for debugging purposes and visual feedback
			LED_DATAIN = !LED_DATAIN;

		} else if (count < 8) {
			// collect data bits
			byte >>= 1;
			if (!RS232_INPUT)
				byte |= 0b10000000;

			// toggle LD10 - for debugging purposes and visual feedback
			LED_DATAIN = !LED_DATAIN;

		} else {
			// check stop bit and store just received data
			if (!RS232_INPUT) {
				rx_buffer[rx.head++] = byte;

				// toggle LD10 - for debugging purposes and visual feedback
				LED_DATAIN = !LED_DATAIN;
			}

cleanup:	// stop bit bang timer
			INTCONbits.T0IE = 0;
			// ... and reset RX change one
			INTCONbits.RAIF = 0;
			INTCONbits.RAIE = 1;
		}

		count++;
	}

	if (INTCONbits.INTE && INTCONbits.INTF) {
		// clear flag
		INTCONbits.INTF = 0;

		button.was_pressed = 1;
//		pressed_ticks = 0;
	}

	// system ticks - every 100 ms
	if (PIR1bits.T1IF) {
		// clear flag
		PIR1bits.T1IF = 0;

		// update
		system_ticks++;
		// reset timer for the next tick
		TMR1 = SYSTIMER_TICKS;
	}
}
